const JWT = require('jsonwebtoken')
const { nextUUID } = require('../datatypes/util')
const { PUBLIC_KEY } = require('./constants')
const algorithm = 'ES384'

module.exports = (client, server, options) => {
  const skinData = require('minecraft-data')('bedrock_' + options.version).defaultSkin
  // TODO: Use feature or ver compare functions
  const protocolVersion = options.protocolVersion || 0
  const useOidcOfflineLogin = protocolVersion >= 944

  client.createClientChain = (mojangKey, offline) => {
    const privateKey = client.ecdhKeyPair.privateKey

    let token
    if (offline) {
      if (useOidcOfflineLogin) {
        token = ''
        client.multiplayerToken = JWT.sign({
          cpk: client.clientX509,
          xid: String(client.profile.xuid || '0'),
          xname: client.username,
          identity: client.profile.uuid,
          // Self-signed OpenID login uses the legacy UUID and an empty
          // Minecraft/PlayFab identity when no service authenticated it.
          leguuid: client.profile.uuid,
          mid: ''
        }, privateKey, { algorithm, notBefore: 0, issuer: 'self', expiresIn: 60 * 60, audience: 'api://auth-minecraft-services/multiplayer', header: { x5u: client.clientX509, typ: undefined } })
      } else {
        const payload = {
          extraData: {
            displayName: client.username,
            identity: client.profile.uuid,
            titleId: '89692877',
            XUID: '0'
          },
          certificateAuthority: true,
          identityPublicKey: client.clientX509
        }
        token = JWT.sign(payload, privateKey, { algorithm, notBefore: 0, issuer: 'self', expiresIn: 60 * 60, header: { x5u: client.clientX509, typ: undefined } })
      }
    } else {
      token = JWT.sign({
        identityPublicKey: mojangKey || PUBLIC_KEY,
        certificateAuthority: true
      }, privateKey, { algorithm, header: { x5u: client.clientX509, typ: undefined } })
    }

    client.clientIdentityChain = token
    client.createClientUserChain(privateKey)
  }

  client.createClientUserChain = (privateKey) => {
    let payload = {
      ...skinData,

      ClientRandomId: process.env.BP_STABLE_ID ? parseInt(require('crypto').createHash('md5').update(client.profile.name).digest('hex').slice(0, 12), 16) : Date.now(),
      CurrentInputMode: 1,
      DefaultInputMode: 1,
      DeviceId: process.env.BP_STABLE_ID ? require('crypto').createHash('md5').update('dev' + client.profile.name).digest('hex').replace(/^(.{8})(.{4})(.{4})(.{4})(.{12}).*$/, '$1-$2-$3-$4-$5') : nextUUID(),
      DeviceModel: 'PrismarineJS',
      DeviceOS: options.deviceOS,
      FilterProfanity: client.versionGreaterThanOrEqualTo('1.26.30') ? false : undefined,
      GameVersion: options.version || '1.16.201',
      GuiScale: -1,
      LanguageCode: 'en_GB', // TODO locale
      GraphicsMode: 1, // 1:simple, 2:fancy, 3:advanced, 4:ray_traced

      PlatformOfflineId: '',
      PlatformOnlineId: '', // chat
      // PlayFabID is the PlayFab ID produced for the skin. PlayFab is the company that hosts the Marketplace,
      // skins and other related features from the game. This ID is the ID of the skin used to store the skin
      // inside of PlayFab.The playfab ID is always lowercased.
      PlayFabId: process.env.BP_STABLE_ID ? require('crypto').createHash('md5').update(client.profile.name).digest('hex').slice(0, 16) : nextUUID().replace(/-/g, '').slice(0, 16).toLowerCase(), // 1.16.210

      SelfSignedId: process.env.BP_STABLE_ID ? require('crypto').createHash('md5').update(client.profile.name).digest('hex').replace(/^(.{8})(.{4})(.{4})(.{4})(.{12}).*$/, '$1-$2-$3-$4-$5') : nextUUID(),
      ServerAddress: `${options.host}:${options.port}`,

      ThirdPartyName: client.profile.name, // Gamertag
      ThirdPartyNameOnly: client.versionGreaterThanOrEqualTo('1.21.90') ? undefined : false,
      UIProfile: 0,

      IsEditorMode: false,
      ClientIsEditorCapable: client.versionGreaterThanOrEqualTo('1.26.30') ? false : undefined,
      ClientEditorConnectionIntent: client.versionGreaterThanOrEqualTo('1.26.30') ? 0 : undefined,
      TrustedSkin: client.versionGreaterThanOrEqualTo('1.19.20') ? false : undefined,
      OverrideSkin: client.versionGreaterThanOrEqualTo('1.19.62') ? false : undefined,
      CompatibleWithClientSideChunkGen: client.versionGreaterThanOrEqualTo('1.19.80') ? false : undefined,

      MaxViewDistance: client.versionGreaterThanOrEqualTo('1.21.42') ? 0 : undefined,
      MemoryTier: client.versionGreaterThanOrEqualTo('1.21.42') ? 0 : undefined,
      PlatformType: client.versionGreaterThanOrEqualTo('1.21.42') ? 0 : undefined
    }
    const customPayload = options.skinData || {}
    payload = { ...payload, ...customPayload }
    payload.DeviceOS = options.deviceOS
    payload.ServerAddress = `${options.host}:${options.port}`

    client.clientUserChain = JWT.sign(payload, privateKey, { algorithm, header: { x5u: client.clientX509, typ: undefined }, noTimestamp: true /* pocketmine.. */ })
  }
}
